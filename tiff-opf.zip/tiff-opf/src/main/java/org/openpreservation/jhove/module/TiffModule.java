package org.openpreservation.jhove.module;

import edu.harvard.hul.ois.jhove.*;

import java.io.IOException;
import java.io.RandomAccessFile;

// Module for checking TIFF conformance.

public class TiffModule extends ModuleBase {

    /**
     * Value to write as module params to the default config file.
     */
    public static final String[] defaultConfigParams = { "byteoffset=true" };

    private static final String NAME = "TIFF-opf"; // Name for the TIFF module created by the Open Preservation Foundation (OPF).
    private static final String RELEASE = "0.1.0"; // Module release identifier/number (major.minor) TODO update date when released
    private static final int[] DATE = {2023, 8, 22}; // Module release date (year, month, day) TODO update date when released
    private static final String[] FORMAT = {"TIFF", "Tag Image File Format"}; // Formats supported by the module.

    // Format profiles covered/supported by the module. TODO update when specs/profiles known
    private static final String COVERAGE = "Baseline and Extended TIFF 6.0; " +
            "TIFF/IT (Profiles P1 and P2); TIFF/EP (ISO 12234-2:2001); TI/A";

    // MIME types applicable for the formats supported by the module.
    private static final String[] MIMETYPE = {"image/tiff", "image/tiff-fx", "image/ief"};

    private static final String WELLFORMED = "A TIFF file is well-formed if "
            + "it has a big-endian or little-endian header; at least one IFD; all "
            + "IFDs are 16-bit word aligned; all IFDs have at least one entry; "
            + "all IFD entries are sorted in ascending order by tag number; all "
            + "IFD entries specify the correct type and count; all value offsets "
            + "are 16-bit word aligned; all value offsets reference locations "
            + "within the file; and the final IFD is followed by an offset of 0";
    private static final String VALIDITY = "A TIFF file is valid if "
            + "well-formed; ImageLength, ImageWidth, and "
            + "PhotometricInterpretation tags are defined; strip or tile tags "
            + "are defined; tag values are self-consistent (see JHOVE "
            + "documentation); TileWidth and TileLength values are integral "
            + "multiples of 16; and DateTime tag is properly formatted";
    private static final String REPINFO = "Additional representation "
            + "information includes: NISO Z39.87 Digital Still Image Technical "
            + "Metadata and all other tag values";
    private static final String NOTE = "This module uses DPF Manager for TIFF conformance checks.";
    private static final String RIGHTS = "Copyright 2023 by Open Preservation Foundation. "
            + "Released under the GNU Lesser General Public License."; // TODO copyright owner check for opf/bl module

    // Module requires random access to file object. Flag set to true and parse method will
    // reflect this access expectation.
    private static final boolean RANDOMACCESS = true;

    /**
     * Internal signature header constants (IFH)
     * */

    // Byte order for little-endian, I.
    private static final int BYTEORDERI = 0x49;

    // Byte order for big-endian, M.
    private static final int BYTEORDERM = 0x4D;

    //
    private static final int TIFFIDENTIFIER = 42;

    // Offset to first IFD.
    private static final int IFDOFFSET = 0; // TODO check this is correct value in spec

    private static final int[] IFHLITTLEENDIAN = { BYTEORDERI, BYTEORDERI, TIFFIDENTIFIER, IFDOFFSET};
    private static final int[] IFHBIGENDIAN = { BYTEORDERM, BYTEORDERM, IFDOFFSET, TIFFIDENTIFIER};

    private static final String FILEFORMATTYPE = "TIFF";
    private static  final String FILEEXTENSION = ".tiff";
    private static final int IFHOFFSET = 0;

    private static final String NOTELITTLEENDIAN = "Little-endian (least significant byte first)";
    private static final String NOTEBIGENDIAN = "Big-endian (most significant byte first)";

    public TiffModule() {
        super(NAME, RELEASE, DATE, FORMAT, COVERAGE, MIMETYPE, WELLFORMED,
                VALIDITY, REPINFO, NOTE, RIGHTS, RANDOMACCESS);

        setVendor();
        setSpecifications();
        setSignatures();
    }

    // Define vendor agent (OPF)
    private void setVendor() {

        _vendor = Agent.opfInstance();
    }
    private void setSpecifications() {

        // Define TIFF 6.0 document with Adobe agent
        defineSpecification(
                Agent.newAdobeInstance(),
                "TIFF, Revision 6.0",
                DocumentType.REPORT,
                "1992-06-03",
                "Final",
                "http://partners.adobe.com/asn/tech/tiff/specification.jsp",
                IdentifierType.URL);

        // Define TIFF/EP document with ISO agent
        defineSpecification(
                Agent.newIsoInstance(),
                "ISO 12234-2:2001, Electronic still-picture "
                        + "imaging -- Removable memory -- "
                        + "Part 2: TIFF/EP image data format",
                DocumentType.STANDARD,
                "2001-10-15",
                "1",
                "ISO 12234-2:2001(E)",
                IdentifierType.ISO);

        /*
        // Define TIFF/IT document, reusing ISO agent TODO cannot find this edition for 2003, check if can change details to 2004 second edition

        doc = new Document("ISO/DIS 12639:2003, Graphic technology -- "
                + "Prepress digital data exchange -- "
                + "Tag image file format for image technology " + "(TIFF/IT)",
                DocumentType.STANDARD);
        doc.setPublisher(isoAgent);
        doc.setDate("2003-09-04");
        ident = new Identifier("ISO/DIS 12639:2003(E)", IdentifierType.ISO);
        doc.setIdentifier(ident);
        _specification.add(doc);
        */
    }

    // Define specification of the file format as handled by the Module.
    private void defineSpecification(Agent publisher, String name, DocumentType specType, String date,
                                     String edition, String identifier, IdentifierType identifierType) {

        Document specification = new Document(name, specType);
        specification.setPublisher(publisher);
        specification.setDate(date);
        specification.setEdition(edition);
        specification.setIdentifier(new Identifier(identifier, identifierType));
        _specification.add(specification);
    }

    private void setSignatures() {

        defineInternalSignature();
        defineExternalSignature();
    }

    private void defineInternalSignature() {

        _signature.add(new InternalSignature(IFHLITTLEENDIAN, SignatureType.MAGIC,
                SignatureUseType.MANDATORY_IF_APPLICABLE, IFHOFFSET,
                NOTELITTLEENDIAN));

        _signature.add(new InternalSignature(IFHBIGENDIAN, SignatureType.MAGIC,
                SignatureUseType.MANDATORY_IF_APPLICABLE, IFHOFFSET,
                NOTEBIGENDIAN));
    }

    private void defineExternalSignature() {

        _signature.add(new ExternalSignature(FILEFORMATTYPE, SignatureType.FILETYPE,
                SignatureUseType.OPTIONAL));

        _signature.add(new ExternalSignature(FILEEXTENSION, SignatureType.EXTENSION,
                SignatureUseType.OPTIONAL));
    }

    /**
     * Parse content of a random access digital object, using DPF Manager validator, and store
     * results in RepInfo.
     *
     * @param file
     *            A RandomAccessFile, positioned at its beginning,
     *            which is generated from the object to be parsed
     * @param info
     *            A fresh RepInfo object which will be modified
     *            to reflect the results of the parsing
     */
    @Override
    public void parse(RandomAccessFile file, RepInfo info) throws IOException {
       // super.parse(file, info);

     //   initParse();


    }
}